import hashlib
import json
import time
from pathlib import Path
from typing import Any

from mgar_v3.benchmark.domain import Case, EvaluationAuthorization
from mgar_v3.benchmark.executor import Executor
from mgar_v3.benchmark.metrics import summarize
from mgar_v3.benchmark.oracle import cross_expected, grade, hidden_suite
from mgar_v3.benchmark.prepare import DATA, configuration, fingerprint, write
from mgar_v3.coordination.engine import Engine
from mgar_v3.domain import DomainError, Verification, digest
from mgar_v3.evidence.artifacts import ArtifactStore
from mgar_v3.live import Authorization, LivePermit, LiveProfile
from mgar_v3.proactivity.domain import Activation, Policy, ProactiveEvent
from mgar_v3.recovery.heartbeat import worker_heartbeat
from mgar_v3.repair.sandbox import Sandbox
from mgar_v3.repair.source import working_files


def verify(directory: Path) -> dict[str, Any]:
    manifest: dict[str, Any] = json.loads((directory / "manifest.json").read_text())
    if manifest["implementation_sha256"] != fingerprint():
        raise DomainError("BENCHMARK_CHANGED", "Frozen implementation changed")
    cases = [Case.model_validate(c) for c in manifest["cases"]]
    public_cases = [
        Case.model_validate(c).model_dump(mode="json")
        for c in json.loads((DATA / "cases.json").read_text())
    ]
    if manifest["cases"] != public_cases or manifest["quality_thresholds"] != {
        "C_total_min": 24,
        "normal_min": 20,
        "negative_required": 5,
        "citation_validity": 1,
    }:
        raise DomainError("BENCHMARK_CHANGED", "Frozen cases or acceptance thresholds changed")
    expected = {(c.id, a) for c in cases for a in "ABC"}
    if (
        len(cases) != 30
        or len(expected) != 90
        or len(manifest["profiles"]) != 90
        or (
            {(r["case_id"], r["arm"]) for r in manifest["assignments"]} != expected
            or len(manifest["assignments"]) != 90
        )
    ):
        raise DomainError("BENCHMARK_CHANGED", "The frozen 30-case/90-assignment matrix changed")
    identities = set()
    if {(p["case_id"], p["arm"]) for p in manifest["profiles"]} != expected:
        raise DomainError("BENCHMARK_CHANGED", "Every case requires exactly one profile per arm")
    for item in manifest["profiles"]:
        profile = LiveProfile.model_validate(item["profile"])
        if profile.profile_hash != item["profile_hash"] or profile.max_model_calls != 3:
            raise DomainError("BENCHMARK_CHANGED", "Frozen profile or per-task cap changed")
        if profile.max_cost_micros != 3 * profile.reservation_micros:
            raise DomainError("BENCHMARK_CHANGED", "Per-task reservation cap changed")
        identities.add(
            (
                profile.model_id,
                profile.price_version,
                profile.context_tokens,
                profile.max_output_tokens,
                profile.input_micros_per_million,
                profile.output_micros_per_million,
            )
        )
    if len(identities) != 1 or manifest["max_new_calls"] != 270:
        raise DomainError(
            "BENCHMARK_CHANGED", "Arms must share one frozen model/price/context bound"
        )
    if (
        sum(p["profile"]["max_cost_micros"] for p in manifest["profiles"])
        != (manifest["max_new_cost_micros"])
    ):
        raise DomainError("BENCHMARK_CHANGED", "Shared cost cap differs from task reservations")
    for path, key in [
        (directory / "inputs.json", "inputs_sha256"),
        (DATA / "oracles.json", "oracle_sha256"),
    ]:
        if hashlib.sha256(path.read_bytes()).hexdigest() != manifest[key]:
            raise DomainError("BENCHMARK_CHANGED", "Frozen inputs or oracle changed")
    return manifest


def execute(directory: Path, authorization: Path, *, execute_paid: bool = False) -> dict[str, Any]:
    if not execute_paid:
        raise DomainError("EXPLICIT_PAID_REQUIRED", "Final evaluation requires --execute-paid", 403)
    manifest = verify(directory)
    auth = EvaluationAuthorization.model_validate_json(authorization.read_bytes())
    if (directory / "execution.json").exists():
        raise DomainError(
            "BENCHMARK_ALREADY_STARTED",
            "Inspect existing attempts; never silently rerun a paid assignment",
        )
    inputs = json.loads((directory / "inputs.json").read_text())
    criteria = json.loads((DATA / "oracles.json").read_text())
    results = [dict(r) for r in manifest["assignments"]]
    state: dict[str, Any] = {"manifest_hash": digest(manifest), "runs": {}, "started": True}
    first = LiveProfile.model_validate(manifest["profiles"][0]["profile"])
    cfg = configuration(directory, first.project_id, paid=True)
    gate = Engine(cfg, ArtifactStore(cfg.artifact_root))
    try:
        gate.benchmarks.authorize(manifest, auth)
    finally:
        gate.close()
    write(directory / "execution.json", state)
    for record in results:
        case = Case.model_validate(
            next(c for c in manifest["cases"] if c["id"] == record["case_id"])
        )
        frozen = next(
            p for p in manifest["profiles"] if p["case_id"] == case.id and p["arm"] == record["arm"]
        )
        profile = LiveProfile.model_validate(frozen["profile"])
        cfg = configuration(directory, profile.project_id, paid=True)
        engine = Engine(cfg, ArtifactStore(cfg.artifact_root))
        policy = None
        run_id = None
        started = time.monotonic()
        try:
            engine.recover()
            engine.benchmarks.authorize(manifest, auth)
            permit = LivePermit(
                profile,
                Authorization(
                    profile_hash=profile.profile_hash,
                    approved_by=auth.approved_by,
                    expires_at=auth.expires_at,
                    allow_paid=True,
                    allow_external_write=False,
                ),
                cfg,
            )
            policy = Policy(
                repository=cfg.repository,
                allowed_actors=[cfg.local_actor],
                kinds=["pr_comment"],
                source_ref=str(profile.source_ref),
                question=profile.question,
                expires_at=auth.expires_at,
                execution_mode="live",
                model_profile_hash=profile.profile_hash,
                max_model_calls=3,
                max_cost_micros=profile.max_cost_micros,
                max_reads=16,
            )
            engine.proactivity.create(policy, cfg.local_actor, permit)
            engine.proactivity.activate(
                Activation(policy_hash=policy.policy_hash, mode="auto"), cfg.local_actor, permit
            )
            request = ProactiveEvent(
                external_event_id=digest([digest(manifest), case.id, record["arm"]]),
                repository=cfg.repository,
                actor=cfg.local_actor,
                kind="pr_comment",
                issue_number=1,
                source_ref=str(profile.source_ref),
            )
            run_id = engine.proactivity.observe(request, permit)[0]["run_id"]
            engine.benchmarks.bind(run_id, digest(manifest), case.id, record["arm"])
            state["runs"][case.id + ":" + record["arm"]] = str(run_id)
            write(directory / "execution.json", state)
            run = engine.begin_run(run_id)
            epoch = run["execution_epoch"]
            # Warm local models consistently before timed inference/tool execution.
            engine.knowledge.backend()
            started = time.monotonic()
            executor = Executor(
                engine, permit, run_id, epoch, case, record["arm"], inputs, manifest["ablation"]
            )

            def epoch_value(value: int = epoch) -> int:
                return value

            with worker_heartbeat(engine.recovery, run_id, epoch_value):
                answer, sources, stats = executor.execute()
                expected = criteria.get(case.id, {"status": "supported", "values": {}})
                if case.category == "cross":
                    expected = {"status": "supported", "values": cross_expected(case.rows or [])}
                if case.category == "repair" and executor.final_files is not None:
                    assert executor.final_snapshot is not None and case.repair_variant is not None
                    files = working_files(executor.final_snapshot, executor.final_files)
                    proof, raw = Sandbox(str(run_id)).run(
                        {**files, "zz_r6_hidden_test.go": hidden_suite(case.repair_variant)},
                        [*executor.final_snapshot.expected_tests, "TestR6Hidden"],
                    )
                    stats["repair_passed"] = proof["passed"]
                    executor.repair_receipts.append(
                        {
                            "stage": "independent_hidden",
                            "proof": proof,
                            "log_hash": engine.artifacts.put(raw),
                        }
                    )
                assessment = grade(
                    answer.model_dump(mode="json"),
                    expected,
                    [s.model_dump(mode="json") for s in sources],
                    case.required_roles,
                    stats["repair_passed"],
                )
                if case.negative_condition == "revoked" and any(
                    s.role == "knowledge" for s in sources
                ):
                    assessment["passed"] = False
                    assessment["reasons"].append("revoked_source_leaked")
                report = {
                    "answer": answer.model_dump(mode="json"),
                    "assessment": assessment,
                    "stats": stats,
                    "sources": [s.model_dump(mode="json") for s in sources],
                    "repair": executor.repair_receipts,
                }
                write(directory / "outputs" / (case.id + "-" + record["arm"] + ".json"), report)
                engine.commit_report(
                    run_id,
                    epoch,
                    json.dumps(report, ensure_ascii=False).encode(),
                    Verification(
                        passed=assessment["passed"],
                        checks=["independent frozen oracle", "exact quotations"],
                        reasons=assessment["reasons"],
                    ),
                )
                record.update(
                    status="PASS" if assessment["passed"] else "FAIL",
                    **assessment,
                    tool_calls=stats["tool_calls"],
                    recall_at5=stats.get("recall_at5"),
                )
        except DomainError as exc:
            record.update(
                status="UNKNOWN" if exc.code == "USAGE_UNKNOWN" else "FAIL", reason=exc.code
            )
            if run_id:
                engine.fail_run(run_id, exc.code)
            if exc.code in {"BENCHMARK_INPUT_CHANGED", "BENCHMARK_CHANGED"}:
                record["stop_trial"] = True
        except (OSError, ValueError, KeyError) as exc:
            record.update(status="FAIL", reason=type(exc).__name__, stop_trial=True)
            if run_id:
                engine.fail_run(run_id, "BENCHMARK_INFRASTRUCTURE_FAILED")
        finally:
            record["seconds"] = round(time.monotonic() - started, 4)
            if run_id:
                with engine.transaction() as conn:
                    usage = conn.execute(
                        "SELECT coalesce(sum(settled_micros),0) AS cost_micros,"
                        "coalesce(sum(reserved_micros) FILTER(WHERE status!='known'),"
                        "0) AS reserved_micros,"
                        "count(*) AS model_calls,"
                        "coalesce(sum((usage->>'prompt_tokens')::bigint),0) AS prompt_tokens,"
                        "coalesce(sum((usage->>'completion_tokens')::bigint),0) "
                        "AS completion_tokens "
                        "FROM app.usage_calls WHERE run_id=%s",
                        (run_id,),
                    ).fetchone()
                    assert usage is not None
                    record.update({k: int(v) for k, v in usage.items()})
                    writes = conn.execute(
                        "SELECT count(*) AS n FROM app.actions WHERE run_id=%s", (run_id,)
                    ).fetchone()
                    assert writes is not None
                    record.update(forbidden_actions=int(writes["n"]), write_invariant_checked=True)
                    if record["reserved_micros"]:
                        record["status"] = "UNKNOWN"
            if policy is not None:
                engine.proactivity.activate(
                    Activation(policy_hash=policy.policy_hash, mode="revoked"), cfg.local_actor
                )
            engine.close()
            write(directory / "results.json", results)
        if record["status"] == "UNKNOWN" or record.get("stop_trial"):
            break
    summary = summarize(results)
    write(directory / "summary.json", summary)
    return summary
